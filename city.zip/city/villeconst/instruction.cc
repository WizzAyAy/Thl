#include "instruction.hh"

instruction::instruction()
{

}
